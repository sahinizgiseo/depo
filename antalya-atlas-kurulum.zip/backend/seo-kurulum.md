# Antalya işletme keşfi panelinin kurulumu

Paneli bir üst dizindeki `server.mjs` dosyası Node.js 22.1 veya üstüyle sunar. Panel dizininde `node server.mjs` çalıştır. Bağlantı ayarları yokken panel örnek verilerle yerelde açılır.

## Google Places ilçe taraması

1. `places-antalya.n8n.json` dosyasını n8n'e içe aktar.
2. **Panel tarama isteği** düğümünde Header Auth kimlik bilgisi seç. Başlık adı `X-IZGI360-Panel-Token`, değeri sunucudaki `N8N_PANEL_TOKEN` ile aynı olmalı.
3. **Google Places** düğümünde mevcut `X-Goog-Api-Key` Header Auth kimlik bilgisini seç.
4. Akışı yayımlayıp **Panel tarama isteği → Production URL** adresini al. Varsayılan yol `/webhook/izgi360-antalya-places`.

Panel her ilçe ve sektör için ayrı istek gönderir. `POST /api/places` örnek gövdesi `{"district":"Muratpaşa","sector":"law"}`. Sektör değerleri `health` (sağlık), `law` (hukuk) ve `hotel` (otel). Sektör gönderilmezse sağlık seçilir.

İş akışı sağlık için 17, hukuk için 5, otel için 6 arama terimi kullanır. Her terimde en fazla üç sayfa alınır. 19 ilçelik taramada üst sınır sağlık için 969, hukuk için 285, otel için 342 Places isteğidir. Üç sektörde toplam üst sınır 1.596 istektir. Bir arama sonuç sınırına ulaşırsa veya bazı kayıtlar doğrulanamazsa ilçe durumu kısmi olarak görünür. Tamamlandı durumu, çalıştırılan sorguların sayfalarını gösterir.

Canlı Google Places işaretlerini harita üzerinde göstermek için **Maps JavaScript API** etkin olmalı. Tarayıcı anahtarını panelin HTTPS adresine ve Maps JavaScript API'ye kısıtla. Bu anahtar, n8n'deki Places anahtarından ayrı tutulur.

## PageSpeed akışı

1. `seo-pagespeed-workflow.json` dosyasını n8n'e içe aktar.
2. **SEO ölçümü isteği** düğümünde Header Auth kimlik bilgisi seç. Başlık adı `X-IZGI360-Panel-Token`, değeri panel sunucusundaki `N8N_PANEL_TOKEN` ile aynı olmalı.
3. **Google PageSpeed Insights** düğümünde mevcut PageSpeed **Query Auth** kimlik bilgisini seç. Query Auth adı `key`.
4. Akışı yayımlayıp **SEO ölçümü isteği → Production URL** adresini al.

## Sunucu ayarları

Dağıtım ortamının gizli ayarlarına aşağıdaki değerleri gir. Sunucu yalnızca `127.0.0.1` üzerinde dinler. Canlıda HTTPS ters vekil üzerinden çalıştır.

| Ayar | Değer |
|---|---|
| `PANEL_USER` | Panel kullanıcı adı |
| `PANEL_PASSWORD` | Panel parolası |
| `PANEL_ORIGIN` | Panelin HTTPS kökeni. Örnek `https://panel.example.com` |
| `N8N_PANEL_TOKEN` | İki n8n akışındaki Header Auth başlığının gizli değeri |
| `N8N_SEO_WEBHOOK_URL` | SEO akışının üretim webhook adresi. Yol `/webhook/izgi360-kesif-seo` |
| `N8N_PLACES_WEBHOOK_URL` | İlçe tarama akışının üretim webhook adresi. Yol `/webhook/izgi360-antalya-places` |
| `GOOGLE_MAPS_BROWSER_KEY` | Maps JavaScript API için panel kökenine kısıtlı tarayıcı anahtarı |
| `PANEL_SITE_STORE_FILE` | Elle girilen web sitesi adresleri için yazılabilir, kalıcı JSON dosyasının mutlak yolu |
| `PORT` | İsteğe bağlı yerel HTTP portu. Varsayılan `8787` |

`GET /api/config` kullanılabilir hizmetleri bildirir. `POST /api/seo` yalnızca `{"url":"https://..."}` gövdesiyle seçili web sitesini Google üzerinden ölçer. SEO ve performans puanları ayrı alanlardır. Başarılı ölçümde bulgular ve Lighthouse tarafından verilen lab metrikleri döner. PageSpeed sonucu döndürmediğinde panel hata alır ve puan göstermez.

`PANEL_SITE_STORE_FILE` ayarlandığında ekibin elle girdiği web sitesi adresleri sunucuda işletme kimliğine göre saklanır. Aynı dosyayı tek panel sunucusu süreci kullanır. Dosyayı dağıtımlar arasında korunan bir diskte tut.

## Panelde kullanım

Sektörü seç, haritada veya ilçe menüsünde bir ilçe seçip **İlçeyi tara** düğmesine bas. **Tüm ilçeler** seçiliyken **Antalya’yı tara** düğmesi ilçeleri sırayla tarar. **İlçe tarama durumu** altında seçili sektörde tamamlanan, kısmi ve başarısız aramalar görünür. Yeni taramalarda Google Places ve Google Maps kullanım ücretleri geçerli olabilir.

Yeşil işletme işareti veya liste satırı seçildiğinde o işletmenin web sitesi için mobil PageSpeed ölçümü çalışır. Pilota ait örnek ölçümler açıkça etiketlenir. Canlı ölçümden üretilen teklif taslağı düzenlenebilir ve kopyalanabilir.

Demo aday ve takip notları tarayıcıda saklanır. Canlı sonuçlar açık oturumda tutulur. İlçe sınırları [Pinlyx Türkiye il ve ilçe verisinden](https://github.com/Pinlyx/turkiye-il-ilce) sadeleştirilmiştir. © OpenStreetMap katkıcıları ve Overture Maps Foundation. [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/).

## Mevcut alan adı altında yayın

Aynı alan adında bir alt dizin kullanılacaksa panel yolunu son eğik çizgiyle aç. Örneğin `/antalya-atlas` isteğini `/antalya-atlas/` yoluna yönlendir. HTTPS vekili yalnızca bu ön eki kaldırarak istekleri panelin Node sunucusuna iletir. n8n editörü ve mevcut webhook yolları kendi hizmetine yönlenmeye devam eder. `PANEL_ORIGIN` değerine yalnızca HTTPS kökenini yaz. Vekil, panelin 120 saniyeye kadar süren iş akışı isteklerini karşılamalı ve `Authorization` başlığını iletmeli.
