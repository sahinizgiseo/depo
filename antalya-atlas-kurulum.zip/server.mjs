import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { mkdir, open, readFile, rename, rm, stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { isIP } from 'node:net';
import { dirname, isAbsolute, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const districts = new Set([
  'Akseki', 'Aksu', 'Alanya', 'Demre', 'Döşemealtı', 'Elmalı', 'Finike',
  'Gazipaşa', 'Gündoğmuş', 'İbradı', 'Kaş', 'Kemer', 'Kepez', 'Konyaaltı',
  'Korkuteli', 'Kumluca', 'Manavgat', 'Muratpaşa', 'Serik',
]);
const sectors = new Set(['health', 'law', 'hotel']);
const upstreamHeader = 'X-IZGI360-Panel-Token';
const pageUrl = new URL('./index.html', import.meta.url);
const mapImageUrl = new URL('./antalya-map-base.webp', import.meta.url);
const requestLimit = 8_192;
const responseLimit = 4_194_304;

function httpsEndpoint(value, name) {
  if (!value) return null;
  const url = URL.parse(value);
  if (!url || url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
    throw new Error(`${name} geçerli bir HTTPS adresi olmalı. Kimlik doğrulama ayrı ayarlanır.`);
  }
  return url.href;
}

export function readPanelConfig(env = process.env) {
  const places = httpsEndpoint(env.N8N_PLACES_WEBHOOK_URL, 'N8N_PLACES_WEBHOOK_URL');
  const seo = httpsEndpoint(env.N8N_SEO_WEBHOOK_URL, 'N8N_SEO_WEBHOOK_URL');
  const token = env.N8N_PANEL_TOKEN || '';
  const mapsApiKey = env.GOOGLE_MAPS_BROWSER_KEY || '';
  const siteStoreFile = env.PANEL_SITE_STORE_FILE || null;
  const user = env.PANEL_USER || '';
  const password = env.PANEL_PASSWORD || '';
  const origin = env.PANEL_ORIGIN ? URL.parse(env.PANEL_ORIGIN)?.origin : null;
  if ((places || seo) && !/^[\x21-\x7e]+$/.test(token)) {
    throw new Error('Canlı n8n bağlantısı için N8N_PANEL_TOKEN ayarlanmalı.');
  }
  if ((places || seo || mapsApiKey || siteStoreFile || user || password) && (!user || !password || user.includes(':'))) {
    throw new Error('PANEL_USER ve PANEL_PASSWORD ayarlanmalı. Kullanıcı adı iki nokta içeremez.');
  }
  if (siteStoreFile && !isAbsolute(siteStoreFile)) {
    throw new Error('PANEL_SITE_STORE_FILE mutlak bir dosya yolu olmalı.');
  }
  if (env.PANEL_ORIGIN && (!origin || !origin.startsWith('https://'))) {
    throw new Error('PANEL_ORIGIN HTTPS kökeni olmalı.');
  }
  if (mapsApiKey && !/^[\w-]+$/.test(mapsApiKey)) {
    throw new Error('GOOGLE_MAPS_BROWSER_KEY biçimi geçersiz.');
  }
  return {
    webhooks: { places, seo },
    token,
    mapsApiKey,
    siteStoreFile,
    origin,
    authorization: user ? 'Basic ' + Buffer.from(`${user}:${password}`, 'utf8').toString('base64') : null,
  };
}

const digest = input => createHash('sha256').update(input).digest();

function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

function publicSite(input) {
  if (typeof input !== 'string' || input.length > 2_048 || /[\s\\]/u.test(input)) return null;
  const url = URL.parse(input);
  if (!url || !['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.port) return null;
  const host = url.hostname.replace(/\.$/, '');
  if (isIP(host) || !/^(?:[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?\.)+[a-z](?:[a-z\d-]{0,61}[a-z\d])$/i.test(host)) return null;
  if (/(?:^|\.)(?:localhost|local|internal|invalid|test|example|onion|home|lan)$/i.test(host)) return null;
  url.hash = '';
  return url.href;
}

function validPlaceId(id) {
  return typeof id === 'string' && /^[A-Za-z0-9_-]{1,255}$/.test(id) &&
    !Object.hasOwn(Object.prototype, id) && id !== 'prototype';
}

async function readSiteOverrides(file) {
  let raw;
  try {
    const info = await stat(file);
    if (!info.isFile() || info.size > responseLimit) throw new Error('Invalid site store');
    raw = await readFile(file, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return Object.create(null);
    throw error;
  }
  const stored = JSON.parse(raw);
  if (!stored || typeof stored !== 'object' || Array.isArray(stored)) throw new Error('Invalid site store');
  const sites = Object.create(null);
  for (const [id, website] of Object.entries(stored)) {
    if (!validPlaceId(id) || !publicSite(website)) throw new Error('Invalid site override');
    sites[id] = website;
  }
  return sites;
}

async function writeSiteOverrides(file, sites) {
  const content = JSON.stringify(sites) + '\n';
  if (Buffer.byteLength(content) > responseLimit) return false;
  const directory = dirname(file);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const tempFile = `${file}.${randomUUID()}.tmp`;
  try {
    const temp = await open(tempFile, 'wx', 0o600);
    try {
      await temp.writeFile(content);
      await temp.sync();
    } finally {
      await temp.close();
    }
    await rename(tempFile, file);
  } finally {
    await rm(tempFile, { force: true });
  }
  return true;
}

async function readPayload(req) {
  const length = Number(req.headers['content-length'] || 0);
  if (length > requestLimit) return null;
  let size = 0;
  const chunks = [];
  try {
    for await (const chunk of req) {
      size += chunk.byteLength;
      if (size > requestLimit) return null;
      chunks.push(chunk);
    }
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    return null;
  }
}

async function readUpstream(response) {
  let size = 0;
  const chunks = [];
  for await (const chunk of response.body ?? []) {
    size += chunk.byteLength;
    if (size > responseLimit) throw new Error('Upstream response too large');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

export function createPanelServer(config, fetchUpstream = globalThis.fetch) {
  const authDigest = config.authorization ? digest(config.authorization) : null;
  const pending = new Map();
  let siteWriteQueue = Promise.resolve();

  async function siteOverrides(req, res) {
    try {
      if (req.method === 'GET') {
        await siteWriteQueue;
        return json(res, 200, { sites: await readSiteOverrides(config.siteStoreFile) });
      }
      const body = await readPayload(req);
      const id = body?.id;
      if (!validPlaceId(id)) return json(res, 400, { error: 'Geçerli bir işletme kimliği girin.' });
      const url = typeof body.url === 'string' ? publicSite(body.url.trim()) : null;
      if (body.url !== null && (!url || url.length > 2_048)) {
        return json(res, 400, { error: 'Geçerli bir web sitesi adresi girin.' });
      }
      const write = siteWriteQueue.then(async () => {
        const sites = await readSiteOverrides(config.siteStoreFile);
        if (url === null) {
          if (!Object.hasOwn(sites, id)) return true;
          delete sites[id];
        } else {
          if (sites[id] === url) return true;
          sites[id] = url;
        }
        return writeSiteOverrides(config.siteStoreFile, sites);
      });
      siteWriteQueue = write.catch(() => {});
      if (!await write) return json(res, 507, { error: 'Web sitesi kayıt deposu dolu.' });
      return json(res, 200, { id, url });
    } catch {
      return json(res, 500, { error: 'Web sitesi kayıt deposuna ulaşılamadı.' });
    }
  }

  async function callWorkflow(service, payload) {
    const response = await fetchUpstream(config.webhooks[service], {
      method: 'POST',
      redirect: 'error',
      headers: { [upstreamHeader]: config.token, 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(120_000),
    });
    if (!response.ok) {
      await response.body?.cancel();
      if (response.status === 429) return [429, { error: 'İstek sınırına ulaşıldı. Bir süre sonra tekrar deneyin.' }];
      if (service === 'seo' && response.status === 422) return [422, { error: 'Google bu web sitesini ölçemedi.' }];
      return [502, { error: 'n8n iş akışı isteği tamamlayamadı.' }];
    }
    const data = await readUpstream(response);
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return [502, { error: 'n8n iş akışı beklenen veri biçimini döndürmedi.' }];
    }
    if (service === 'places' && (
      data.district !== payload.district || data.sector !== payload.sector ||
      !Array.isArray(data.records) || !data.coverage ||
      typeof data.coverage !== 'object' || Array.isArray(data.coverage)
    )) {
      return [502, { error: 'n8n iş akışı tarama sonuçlarını döndürmedi.' }];
    }
    if (service === 'seo' && (data.strategy !== 'mobile' || !Array.isArray(data.findings))) {
      return [502, { error: 'n8n iş akışı ölçüm sonuçlarını döndürmedi.' }];
    }
    return [200, data];
  }

  return createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    if (authDigest && !timingSafeEqual(authDigest, digest(req.headers.authorization || ''))) {
      res.setHeader('WWW-Authenticate', 'Basic realm="IZGI360 Panel", charset="UTF-8"');
      return json(res, 401, { error: 'Panel giriş bilgileri gerekli.' });
    }

    try {
      const path = new URL(req.url || '/', 'http://localhost').pathname;
      if (['/', '/index.html'].includes(path) && ['GET', 'HEAD'].includes(req.method)) {
        const page = await readFile(pageUrl);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': page.byteLength });
        return res.end(req.method === 'HEAD' ? undefined : page);
      }
      if (path === '/antalya-map-base.webp' && ['GET', 'HEAD'].includes(req.method)) {
        const mapImage = await readFile(mapImageUrl).catch(error => {
          if (error.code === 'ENOENT') return null;
          throw error;
        });
        if (!mapImage) return json(res, 404, { error: 'Harita görseli bulunamadı.' });
        res.writeHead(200, { 'Content-Type': 'image/webp', 'Content-Length': mapImage.byteLength });
        return res.end(req.method === 'HEAD' ? undefined : mapImage);
      }
      if (path === '/api/config' && req.method === 'GET') {
        return json(res, 200, {
          placesEnabled: Boolean(config.webhooks.places),
          seoEnabled: Boolean(config.webhooks.seo),
          mapsApiKey: config.mapsApiKey || null,
          siteOverridesEnabled: Boolean(config.siteStoreFile),
        });
      }
      const service = path === '/api/places' ? 'places' : path === '/api/seo' ? 'seo' : null;
      const siteRoute = path === '/api/site-overrides';
      if (!service && !siteRoute) return json(res, 404, { error: 'Sayfa bulunamadı.' });
      if (req.method !== 'POST' && !(siteRoute && req.method === 'GET')) {
        res.setHeader('Allow', siteRoute ? 'GET, POST' : 'POST');
        return json(res, 405, { error: 'İstek yöntemi geçersiz.' });
      }
      const origin = req.headers.origin;
      const expectedOrigins = config.origin ? [config.origin] : [`https://${req.headers.host}`, `http://${req.headers.host}`];
      if (req.headers['sec-fetch-site'] === 'cross-site' || (origin && !expectedOrigins.includes(origin))) {
        return json(res, 403, { error: 'İstek bu panelden gönderilmeli.' });
      }
      if (siteRoute && !config.siteStoreFile) return json(res, 503, { error: 'Web sitesi kayıt deposu henüz ayarlanmadı.' });
      if (!siteRoute && !config.webhooks[service]) return json(res, 503, { error: 'Canlı iş akışı bağlantısı henüz kurulmadı.' });
      if (req.method === 'POST' && !/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) {
        return json(res, 415, { error: 'İstek JSON biçiminde olmalı.' });
      }
      if (siteRoute) return await siteOverrides(req, res);

      const body = await readPayload(req);
      let payload;
      if (service === 'places') {
        const district = typeof body?.district === 'string' ? body.district.normalize('NFC') : '';
        const sector = body?.sector === undefined ? 'health' : body.sector;
        if (!districts.has(district)) return json(res, 400, { error: 'Geçerli bir Antalya ilçesi seçin.' });
        if (!sectors.has(sector)) return json(res, 400, { error: 'Geçerli bir sektör seçin.' });
        payload = { district, sector };
      } else {
        const url = publicSite(body?.url);
        if (!url) return json(res, 400, { error: 'Geçerli bir web sitesi adresi girin.' });
        payload = { url };
      }

      const key = JSON.stringify([service, payload]);
      let result = pending.get(key);
      if (!result) {
        if (pending.size >= 6) return json(res, 429, { error: 'İşlemler tamamlanınca tekrar deneyin.' });
        result = callWorkflow(service, payload).finally(() => pending.delete(key));
        pending.set(key, result);
      }
      const [status, data] = await result;
      return json(res, status, data);
    } catch (error) {
      const timeout = error?.name === 'TimeoutError' || error?.name === 'AbortError';
      return json(res, timeout ? 504 : 502, { error: timeout ? 'İş akışı zamanında sonuç vermedi.' : 'Panel isteği tamamlanamadı.' });
    }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8787);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT geçerli bir TCP portu olmalı.');
  createPanelServer(readPanelConfig()).listen(port, '127.0.0.1', () => {
    console.log(`İZGİ360 paneli http://127.0.0.1:${port}`);
  });
}
